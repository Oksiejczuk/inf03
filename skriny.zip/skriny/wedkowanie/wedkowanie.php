<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl2.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klub wędkowania</title>
</head>
<body>
    <section class="baner">
        <h2>wedkuj z nami </h2>
    </section>
    <section class="lewy">
        <img src="ryba2.jpg" alt="szczupak">
    </section>
    <section class="prawy">
        <h3>ryby spokojnego żeru (białe)</h3>
        <?php
            $connect = mysqli_connect('localhost','root','','wedkowanie2');
            $query = mysqli_query($connect, "SELECT id, nazwa, wystepowanie FROM ryby WHERE styl_zycia = 2;");

            while($element = mysqli_fetch_array($query)){
                echo $element['id']." ".$element['nazwa']." Występuje w : ".$element['wystepowanie']."<br>";
            }

            mysqli_close($connect);

        ?>
        <ol>
            <li><a href="https://wedkuje.pl" target="_blank">Odwiedź także</a></li>
            <li><a href="https://www.pzw.org.pl/" target="_blank">Polski Zawiązek Wędkarski</a></li>
        </ol>
    </section>
    <footer>
        <p>strone wykonał; krzyś</p>
    </footer>
</body>
</html>
