<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl_1.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wędkujemy</title>
</head>
<body>
    <section class="baner">
        <h1>Portal dla wędkarzy </h1>
    </section>
    <section class="lewy">
        <h2>Ryby drapieżne naszych wód</h2>
        <ul>
            <?php
                $connect = mysqli_connect('localhost','root','','wedkowanie');

                $query = mysqli_query($connect, "SELECT `nazwa`,`wystepowanie` FROM `ryby` WHERE 1");

                while ($row = mysqli_fetch_array($query)) {
                    echo "<li>".$row['nazwa'].", Występowanie: ".$row['wystepowanie']."</li>";
                    
                }
                mysqli_close($connect);
            ?>
        </ul>
    </section>
    <section class="prawy"><img src="ryba1.jpg" alt="Sum"><br><a href="kwerendy.txt">Pobierz kwerendy</a></section> 
    <footer><p>strone wykonał xyz</p></footer>
</body>
</html>