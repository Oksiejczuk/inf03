<?php
    $connect = mysqli_connect('localhost','root','','zawody');
    $lowisko = $_POST['lowisko'];
    $data =$_POST['data'];
    $sedzia = $_POST['sedzia'];
    
    
    
    mysqli_query($connect,"INSERT INTO `zawody_wedkarskie`(`Karty_wedkarskie_id`, `Lowisko_id`, `data_zawodow`, `sedzia`) VALUES (0,'$lowisko','$data','$sedzia')");
    
    
    
    
    
    
    
    
    
    
    
    mysqli_close($connect);
?>